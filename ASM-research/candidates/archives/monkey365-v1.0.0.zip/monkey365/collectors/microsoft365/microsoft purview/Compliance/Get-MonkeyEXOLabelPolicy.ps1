﻿# Monkey365 - the PowerShell Cloud Security Tool for Azure and Microsoft 365 (copyright 2022) by Juan Garrido
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


function Get-MonkeyEXOLabelPolicy {
<#
        .SYNOPSIS
		Collector to get information about label policies from Exchange Online

        .DESCRIPTION
		Collector to get information about label policies from Exchange Online

        .INPUTS

        .OUTPUTS

        .EXAMPLE

        .NOTES
	        Author		: Juan Garrido
            Twitter		: @tr1ana
            File Name	: Get-MonkeyEXOLabelPolicy
            Version     : 1.0

        .LINK
            https://github.com/silverhack/monkey365
    #>

	[CmdletBinding()]
	param(
		[Parameter(Mandatory = $false,HelpMessage = "Background Collector ID")]
		[string]$collectorId
	)
	begin {
		$label_policy = $null;
		#Collector metadata
		$monkey_metadata = @{
			Id = "purv006";
			Provider = "Microsoft365";
			Resource = "Purview";
			ResourceType = $null;
			resourceName = $null;
			collectorName = "Get-MonkeyEXOLabelPolicy";
			ApiType = $null;
            objectType = 'PurviewLabelPolicy';
            immutableProperties = @(
                'OrganizationId',
                'ExchangeObjectId.Guid'
            );
			description = "Collector to get information about label policies from Exchange Online";
			Group = @(
				"Purview"
			);
			Tags = @(

			);
			references = @(
				"https://silverhack.github.io/monkey365/"
			);
			ruleSuffixes = @(
				"o365_secomp_label_policy"
			);
			dependsOn = @(
				"ExchangeOnline"
			);
			enabled = $true;
			supportClientCredential = $true
		}
	}
	process {
		if ($O365Object.onlineServices.Purview -eq $true) {
			$msg = @{
				MessageData = ($message.MonkeyGenericTaskMessage -f $collectorId,"Security and Compliance label policy",$O365Object.TenantID);
				callStack = (Get-PSCallStack | Select-Object -First 1);
				logLevel = 'info';
				InformationAction = $O365Object.InformationAction;
				Tags = @('SecCompLabelPolicyInfo');
			}
			Write-Information @msg
			#Get Security and Compliance Auth token
			$ExoAuth = $O365Object.auth_tokens.ComplianceCenter
			#Get Backend Uri
			$Uri = $O365Object.SecCompBackendUri
			#InitParams
			$p = @{
				Authentication = $ExoAuth;
				EndPoint = $Uri;
				ResponseFormat = 'clixml';
				Command = 'Get-LabelPolicy -WarningAction SilentlyContinue';
				Method = "POST";
				InformationAction = $O365Object.InformationAction;
				Verbose = $O365Object.Verbose;
				Debug = $O365Object.Debug;
			}
			#Get label policy
			$label_policy = Get-PSExoAdminApiObject @p
            If($null -ne $label_policy){
                $label_policy = [System.Collections.Generic.List[System.Object]]::new()
                $mockLabel = [PsCustomObject]@{
                    Name = 'Monkey365LabelNotSet';
                    Comment = 'Label Policies were not found'
                    Guid = [System.GUID]::Empty.Guid;
                    ExchangeObjectId = [System.GUID]::Empty.Guid;
                    IsValid = $false;
                    Enabled = $false;
                }
                [void]$label_policy.Add($mockLabel);
            }
		}
	}
	End {
		If ($null -ne $label_policy) {
			$label_policy.PSObject.TypeNames.Insert(0,'Monkey365.SecurityCompliance.labelPolicy')
			[pscustomobject]$obj = @{
				Data = $label_policy;
				Metadata = $monkey_metadata;
			}
			$returnData.o365_secomp_label_policy = $obj
		}
		Else {
			$msg = @{
				MessageData = ($message.MonkeyEmptyResponseMessage -f "Security and Compliance label policy",$O365Object.TenantID);
				callStack = (Get-PSCallStack | Select-Object -First 1);
				logLevel = "verbose";
				InformationAction = $O365Object.InformationAction;
				Tags = @('SecCompLabelPolicyEmptyResponse');
				Verbose = $O365Object.Verbose;
			}
			Write-Verbose @msg
		}
	}
}









