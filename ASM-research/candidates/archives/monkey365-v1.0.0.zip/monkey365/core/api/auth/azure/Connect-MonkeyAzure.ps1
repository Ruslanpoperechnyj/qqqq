﻿# Monkey365 - the PowerShell Cloud Security Tool for Azure and Microsoft 365 (copyright 2022) by Juan Garrido
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

Function Connect-MonkeyAzure{
    <#
        .SYNOPSIS

        .DESCRIPTION

        .INPUTS

        .OUTPUTS

        .EXAMPLE

        .NOTES
	        Author		: Juan Garrido
            Twitter		: @tr1ana
            File Name	: Connect-MonkeyAzure
            Version     : 1.0

        .LINK
            https://github.com/silverhack/monkey365
    #>
    [CmdletBinding()]
    Param (
        [parameter(Mandatory=$false, HelpMessage="Used when tokens are imported from init param")]
        [Switch]$Connected
    )
    Begin{
        $azure_services = @{
            ResourceManager = $O365Object.Environment.ResourceManager;
            ServiceManagement = $O365Object.Environment.Servicemanagement;
            SecurityPortal = $O365Object.Environment.Servicemanagement;
            AzureStorage = $O365Object.Environment.Storage;
            AzureVault = $O365Object.Environment.Vaults;
            LogAnalytics = $O365Object.Environment.LogAnalytics;
        }
        $app_params = @{
            Resource = $null;
            AzureService = "AzurePowershell";
            InformationAction = $O365Object.InformationAction;
            Verbose = $O365Object.verbose;
            Debug = $O365Object.debug;
        }
    }
    Process{
        If($null -ne $O365Object.auth_tokens.ResourceManager){
            $O365Object.subscriptions = Select-MonkeyAzureSubscription
        }
    }
    End{
        If($null -ne $O365Object.subscriptions -and $null -ne $app_params){
            ForEach($service in $azure_services.GetEnumerator()){
                $msg = @{
                    MessageData = ($message.TokenRequestInfoMessage -f $service.Name)
                    callStack = (Get-PSCallStack | Select-Object -First 1);
                    logLevel = 'info';
                    InformationAction = $O365Object.InformationAction;
                    Tags = @('TokenRequestInfoMessage');
                }
                Write-Information @msg
                $azure_service = $service.Name
                #Get new parameters
                $new_params = @{}
                foreach ($param in $app_params.GetEnumerator()){
                    $new_params.add($param.Key, $param.Value)
                }
                #Add resource parameter
                $new_params.Resource = $service.Value
                try{
                    IF(!$Connected.IsPresent){
                        $O365Object.auth_tokens.$($azure_service) = Connect-MonkeyGenericApplication @new_params
                        $msg = @{
                            MessageData = ($message.TokenAcquiredInfoMessage -f $service.Name)
                            callStack = (Get-PSCallStack | Select-Object -First 1);
                            logLevel = 'info';
                            InformationAction = $O365Object.InformationAction;
                            Tags = @('TokenAcquiredMessage');
                        }
                        Write-Information @msg
                    }
                }
                catch{
                    $msg = @{
                        MessageData = ($message.UnableToGetAccessToken -f $service.Name)
                        callStack = (Get-PSCallStack | Select-Object -First 1);
                        logLevel = 'info';
                        InformationAction = $O365Object.InformationAction;
                        Tags = @('TokenErrorMessage');
                    }
                    Write-Warning @msg
                    if($O365Object.auth_tokens.ContainsKey($azure_service)){
                        $O365Object.auth_tokens.$($azure_service) = $null
                    }
                    else{
                        [ref]$null = $O365Object.auth_tokens.Add($azure_service,$null)
                    }
                    $msg = @{
                        MessageData = $_;
                        callStack = (Get-PSCallStack | Select-Object -First 1);
                        logLevel = 'verbose';
                        InformationAction = $O365Object.InformationAction;
                        Verbose = $O365Object.verbose;
                        Tags = @('TokenError');
                    }
                    Write-Verbose $_
                }
            }
        }
    }
}